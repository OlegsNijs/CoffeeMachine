using TaskLibrary;

namespace TestProject1
{
        [TestClass]
        public class UnitTest1
        {
            [TestMethod]
            public void TestMethod1()
            {
                double expectedResult = 2.60;
                double coin1 = 1.00;
                double coin2 = 1.00;
                double coin3 = 0.50;
                double coin4 = 0.10;

                CoffeeMachine coinValue = new CoffeeMachine();
                Assert.AreEqual(expectedResult, coinValue.CoinValue(coin1, coin2, coin3, coin4));
            }


            [TestMethod]
            public void TestMethod2()
            {
                double result = 2.60;
                double coin1 = 1.00;
                double coin2 = 1.00;
                double coin3 = 0.50;
                double coin4 = 0.10;
                string expectedResult = "The used coin values are " + coin1.ToString() + " " + coin2.ToString() + " " + coin3.ToString() + " " + coin4.ToString()
        + "The total is " + result;

                CoffeeMachine coinInfo = new CoffeeMachine();
                Assert.AreEqual(expectedResult, coinInfo.CoinInfo(coin1, coin2, coin3, coin4));
            }

            [TestMethod]
            public void TestMethod3()
            {
                double coin1 = 1.00;
                double coin2 = 0.50;
                double coin3 = 0.50;
                double coin4 = 0.10;
                string productLatte = "Latte";
                double lattePrice = 2.50;
                string productCapuchino = "Capuchino";
                double capuchinoPrice = 1.50;
                string expectedResult = "Capuchino";
                string noMoney = "No Money";

                CoffeeMachine getProduct = new CoffeeMachine();
                Assert.AreEqual(expectedResult, getProduct.GetProduct(coin1, coin2, coin3, coin4, productLatte, lattePrice, productCapuchino, capuchinoPrice, noMoney));
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestMethod4()
        {
            double coin1 = 0.10;
            double coin2 = 0.50;
            double coin3 = 0.50;
            double coin4 = 0.10;
            string productLatte = "Latte";
            double lattePrice = 2.50;
            string productCapuchino = "Capuchino";
            double capuchinoPrice = 1.50;
            double expectedResult = 1.20;
            string noMoney = "No Money";

            CoffeeMachine getChange = new CoffeeMachine();
            getChange.GetChange(coin1, coin2, coin3, coin4, productLatte, lattePrice, productCapuchino, capuchinoPrice, noMoney);
        }
    }
}